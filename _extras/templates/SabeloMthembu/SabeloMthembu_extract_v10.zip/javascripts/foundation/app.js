$(document).ready(function() {

	/* Use this js doc for all application specific JS */
  $(window).resize(function() {
    console.log($(window).width());
  });

	/* TABS --------------------------------- */
	/* Remove if you don't need :) */
	
	var tabs = $('dl.tabs');
		tabsContent = $('ul.tabs-content')
	
	tabs.each(function(i) {
		//Get all tabs
		var tab = $(this).children('dd').children('a');
		tab.click(function(e) {
			
			//Get Location of tab's content
			var contentLocation = $(this).attr("href")
			contentLocation = contentLocation + "Tab";
			
			//Let go if not a hashed one
			if(contentLocation.charAt(0)=="#") {
			
				e.preventDefault();
			
				//Make Tab Active
				tab.removeClass('active');
				$(this).addClass('active');
				
				//Show Tab Content
				$(contentLocation).parent('.tabs-content').children('li').css({"display":"none"});
				$(contentLocation).css({"display":"block"});
				
			} 
		});
	});
	
	
	/* PLACEHOLDER FOR FORMS ------------- */
	/* Remove this and jquery.placeholder.min.js if you don't need :) */
	
	$('input, textarea').placeholder();
	
	
	/* Site Specific  ------------- */
	/* Remove this and jquery.placeholder.min.js if you don't need :) */
	$('#pics_orbit').orbit({
		directionalNav: false,
		bullets: true
	});
	

	/* Events page - Event info toggle */
	$('.moreinfo a').click(function(e) {
		var a = this;
		e.preventDefault();
		var event = $(this).closest('.event');
		var extinfo = $(event).find('.extinfo');
		$(extinfo).animate({
		    height: 'toggle'
		  },500,function(){
			  if( $(extinfo).css('display') == 'block' )
			  {$(a).html('-');}
			  else{$(a).html('+');}
		  });
	});

	/* This is to scroll the window to the location of the selected event when coming in from a Events tab click */
	function getParameterByName() {
		var match;
		var url = window.location.href;
	    if(url.indexOf('#') != -1){
	    	var hash = url.split('#');
	    	return hash[1];
	    }
	    return null;
	}
	
	
	var eventid = getParameterByName();
	if(eventid != null){
		eventid = "#" + eventid;  
		$(eventid).find(".moreinfo a.button").click();
		$.scrollTo("'"+eventid+"'",1000);
	}
	
	$("#contactform").submit(function(){
		
		$("#contactform .validator").each(function(){
			$(this).removeClass('errorfield');
		}).end().find('.errorinfo').remove();
		
		
		var formdata = $("#contactform").serialize();
		
		
		var validform = validator(formdata);
                var actionUrl = $( '#contactform' ).attr( 'action' );
		
		if(validform){
			$.ajax({
				type: "POST",
                url: actionUrl,
				data: formdata,
				dataType: "json",
	
				success: function(msg){
					if(msg.status){
						$('.callback').removeClass('failure');
						$('.callback').addClass('success').text(msg.message);
					}
					else{
						$('.callback').addClass('failure').text(msg.message);
						if(msg.errors.name){
							var field = $("[name='name']");
							$(field).addClass('errorfield').after("<span class='errorinfo'>"+ msg.errors.name +"</span>");
						}
						if(msg.errors.email){
							var field = $("[name='email']");
							$(field).addClass('errorfield').after("<span class='errorinfo'>"+ msg.errors.email +"</span>");
						}
						if(msg.errors.message){
							var field = $("[name='message']");
							$(field).addClass('errorfield').after("<span class='errorinfo'>"+ msg.errors.message +"</span>");
						}
						
					}
	
				},
				error: function(){
					$('.callback').addClass('failure').text("We have encountered a problem. Please try again.");
				}
			});
		}

		//make sure the form doesn't post
		return false;
		
	});	
	
	function validator(formdata){
		var formdataarray = formdata.split('&');
		var validflag = true;
		
		//alert('Before validation');
		
		for(var i in formdataarray){
		
			//alert('i = ' + i );
		
			var value = formdataarray[i].split('=');
			
			//alert('value[' + i + '] = ' + (value[i]));
			//alert( 'trimmed value = _' + $.trim( value[i] ) + '_' );
			
			if( $.trim(value[1]) == ''){
				
				//alert('position 1');
				
				var field = $("[name='"+value[0]+"']");
				$(field).addClass('errorfield').after('<span class="errorinfo">This is a required field</span');
				
				validflag = false;
				break;
			}
			else if(value[0] == "email"){
				if(value[1]) {                    
                    var regexp = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
                    var field = $("[name='"+value[0]+"']");
                    
                    var email = $(field).val();
                    
                    if(!(regexp.test(email))){
                    	
        				$(field).addClass('errorfield').after('<span class="errorinfo">Email is not valid</span');
                    	
                    	validflag = false;
						
						//alert('position 2');
						
						break;
                    }
                }
				else{
					var field = $("[name='"+value[0]+"']");
					$(field).addClass('errorfield').after('<span class="errorinfo">This is a required field</span');
					
					validflag = false;
					
					//alert('position 3');
					
					break;
				}
			}
			
		}
		
		//alert('Final Validation Status = ' + validflag);
		
		return validflag;
	}
});

